/*
 *  UCF COP3330 Fall 2021 Assignment 5 Solution
 *  Copyright 2021 Sarim Jatt
 */
 
 #include <iostream>

using namespace std;

int main() {
  int number;
  cin >> number;

  if(number %2 == 0)
    cout << "The value " << number << " is an even number";
  else
    cout << "The value " << number << " is an odd number.";
  
  return 0;
} 